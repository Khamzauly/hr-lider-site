const TG_TOKEN = process.env.TG_TOKEN;
const CHAT_ID = process.env.CHAT_ID;
const ALLOWED_ORIGINS = ['https://hr-lider.kz', 'https://www.hr-lider.kz'];

export default async function handler(req, res) {
  const origin = req.headers.origin || '';
  const allowed = ALLOWED_ORIGINS.some(o => origin.startsWith(o));
  
  res.setHeader('Access-Control-Allow-Origin', allowed ? origin : ALLOWED_ORIGINS[0]);
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ ok: false, error: 'Method not allowed' });

  const { name, phone, company } = req.body;

  if (!name || !/^[A-Za-zА-Яа-яЁёӘәҒғҚқҢңӨөҰұҮүІіҺһ\s\-]{2,50}$/.test(name.trim())) {
    return res.status(400).json({ ok: false, error: 'Invalid name' });
  }
  if (!phone || !/^\+?[0-9\s\-\(\)]{7,18}$/.test(phone.trim())) {
    return res.status(400).json({ ok: false, error: 'Invalid phone' });
  }
  if (company && !/^[A-Za-zА-Яа-яЁёӘәҒғҚқҢңӨөҰұҮүІіҺһ0-9\s\-\.\,\"\'«»]{2,100}$/.test(company.trim())) {
    return res.status(400).json({ ok: false, error: 'Invalid company' });
  }

  const text = `📋 *Новая заявка с сайта HR Лидер*\n\n👤 *Имя:* ${name.trim()}\n📞 *Телефон:* ${phone.trim()}${company ? '\n🏢 *Компания:* ' + company.trim() : ''}\n\n📅 *Дата:* ${new Date().toLocaleString('ru-RU', { timeZone: 'Asia/Almaty' })}`;

  try {
    const tgRes = await fetch(`https://api.telegram.org/bot${TG_TOKEN}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: CHAT_ID, text, parse_mode: 'Markdown' }),
    });
    const data = await tgRes.json();

    if (data.ok) return res.json({ ok: true });
    return res.status(500).json({ ok: false, error: 'Telegram error' });
  } catch (e) {
    return res.status(500).json({ ok: false, error: 'Server error' });
  }
}
